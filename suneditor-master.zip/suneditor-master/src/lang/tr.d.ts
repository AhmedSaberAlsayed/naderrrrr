import { Lang } from "./Lang";

declare const tr: Lang;

export default tr;
