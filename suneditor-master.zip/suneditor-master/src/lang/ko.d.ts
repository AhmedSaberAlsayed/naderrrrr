import { Lang } from './Lang';

declare const ko: Lang;

export default ko;