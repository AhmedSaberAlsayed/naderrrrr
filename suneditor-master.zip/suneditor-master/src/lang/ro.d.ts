import { Lang } from './Lang';

declare const ro: Lang;

export default ro;