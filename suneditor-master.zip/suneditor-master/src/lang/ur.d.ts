import { Lang } from './Lang';

declare const ur: Lang;

export default ur;