import { SubmenuPlugin } from '../SubmenuPlugin';

declare const list: SubmenuPlugin;

export default list;