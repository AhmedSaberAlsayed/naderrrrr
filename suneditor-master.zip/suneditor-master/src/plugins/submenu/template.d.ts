import { SubmenuPlugin } from '../SubmenuPlugin';

declare const template: SubmenuPlugin;

export default template;