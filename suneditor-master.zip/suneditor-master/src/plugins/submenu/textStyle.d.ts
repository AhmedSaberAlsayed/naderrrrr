import { SubmenuPlugin } from '../SubmenuPlugin';

declare const textStyle: SubmenuPlugin;

export default textStyle;