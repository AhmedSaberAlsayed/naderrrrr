import { FileBrowserPlugin } from '../FileBrowserPlugin';

declare const imageGallery: FileBrowserPlugin;

export default imageGallery;