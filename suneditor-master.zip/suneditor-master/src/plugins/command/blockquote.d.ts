import { CommandPlugin } from '../CommandPlugin';

declare const blockquote: CommandPlugin;

export default blockquote;